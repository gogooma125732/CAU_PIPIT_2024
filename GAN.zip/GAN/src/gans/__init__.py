from .gan import GAN
from .wgan import WGAN
from .wgangp import WGANGP
from .sngan import SNGAN

from ._base import Base as GANLike
