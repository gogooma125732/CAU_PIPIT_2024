epochs: int = 1000
lr: float = 1e-3
